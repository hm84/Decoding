class Registration:
    def __init__(self):
        self.acceptable_users = []  
        self.acceptable_passwords = []   

    def check_registration_rules(self, user_name, pass_word):     # تابع اصلی شماره یک
        if user_name=='james' or user_name=='fabio' or len(user_name) < 4 or len(pass_word) < 6 or pass_word.isdigit():
            pass
        return user_name, pass_word  

    def prime_numbers(self, num):                                # تابع اصلی شماره دو
        for i in range(2, (num//2)+1):     
            if num % i == 0:
                return False
        return True


    def read_users_from_file(self, file_name):
        f1=open('Names.txt' , 'r')
        f1.readline()
        stop_character=','
        for line in f1:
            u,p=[x.strip() for x in line.split(stop_character)]
            t1,t2=self.check_registration_rules(u,p)
            self.acceptable_users.append(t1)
            self.acceptable_passwords.append(t2)      
        f1.close()


    def write_prime_numbers(self, output_file):
        final=[]
        f2=open("Names2.txt" , "r")
        names=[line.strip() for line in f2]  
        f2.close()
        for i,target_name in enumerate(self.acceptable_users):
            for n in names:
                if target_name==n:
                    final.append(self.acceptable_passwords[i])


    
        Numbers=[]
        for j in final:
            f=0
            temp=""
            for p in range(len(j)):
                if f==3:
                    break
                if j[p].isdigit()==True:
                    temp+=j[p]
                    f+=1
            Numbers.append(temp)


        f3=open('Names3.txt' , 'w')
        for k in Numbers:
            if k.isdigit():
                num=int(k)
                if self.prime_numbers(num):
                    f3.write(f"{num}\n")
        f3.close()

  