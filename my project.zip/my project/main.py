from my_class import Registration    

registration = Registration()
registration.read_users_from_file('Names.txt')
registration.write_prime_numbers('Names3.txt')



